#LPA04

numero = int(input("Digite um numero de 1 a 10: "))

for num in range (1,11): 
    tabuada = numero * num
    print(f"{numero} X {num} =",tabuada)